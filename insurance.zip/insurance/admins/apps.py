from django.apps import AppConfig


class adminsConfig(AppConfig):
    name = 'admins'
